import 'dart:convert';
part 'subModel/restaurants.dart';
part 'subModel/menu.dart';
part 'subModel/option.dart';
