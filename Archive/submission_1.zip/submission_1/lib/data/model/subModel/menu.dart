part of '../model.dart';

class Menu {
  late List<Option> foods;
  late List<Option> drinks;

  Menu({
    required this.foods,
    required this.drinks,
  });

  factory Menu.fromJson(Map<String, dynamic> json) => Menu(
      drinks: List<Option>.from(json['drinks'].map((i) => Option.fromJson(i))),
      foods: List<Option>.from(json['foods'].map((i) => Option.fromJson(i))));
}
