part of '../model.dart';

class Option {
  late String name;

  Option({
    required this.name,
  });

  Option.fromJson(Map<String, dynamic> option) {
    name = option['name'];
  }
}
