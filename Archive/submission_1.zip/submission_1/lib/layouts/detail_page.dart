import 'package:restaurant_app/common/styles.dart';
import 'package:restaurant_app/data/model/model.dart';
import 'package:flutter/material.dart';

class DetailPage extends StatelessWidget {
  static const routeName = '/detail';

  final Restaurant restaurant;

  const DetailPage({Key? key, required this.restaurant}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Widget optionList(Option option) {
      return Padding(
        padding: const EdgeInsets.all(4.0),
        child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Container(
              color: menuColor,
              height: 40,
              alignment: Alignment.center,
              padding: const EdgeInsets.all(8.0),
              child: Text(
                option.name,
                style: Theme.of(context).textTheme.bodyText2,
              ),
            )),
      );
    }

    Widget header(String text) {
      return Container(
        color: menuHeaderColor,
        height: 50,
        child: Center(
          child: Text(
            text,
            style: Theme.of(context).textTheme.headline6,
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        title: Text('Detail ${restaurant.name}'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Hero(
                tag: restaurant.pictureId,
                child: Image.network(restaurant.pictureId)),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    restaurant.name,
                    style: Theme.of(context).textTheme.headline4,
                  ),
                  const Divider(color: dividerColor),
                  Text(
                    'City: ${restaurant.city}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Rating: ${restaurant.rating}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const Divider(color: dividerColor),
                  Text(
                    restaurant.description,
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                  const SizedBox(height: 50),
                  Text('Menu', style: Theme.of(context).textTheme.headline5),
                  const Divider(color: dividerColor),
                  const SizedBox(height: 5),
                ],
              ),
            ),
            header('Food'),
            SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: restaurant.menu!.foods.map(optionList).toList(),
              ),
            ),
            const SizedBox(height: 10),
            header('Drink'),
            SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: restaurant.menu!.drinks.map(optionList).toList(),
              ),
            ),
            const Divider(color: dividerColor),
          ],
        ),
      ),
    );
  }
}
