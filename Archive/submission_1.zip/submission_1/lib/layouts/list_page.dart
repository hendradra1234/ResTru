import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:restaurant_app/common/styles.dart';
import 'package:restaurant_app/data/model/model.dart';
import 'package:restaurant_app/layouts/detail_page.dart';
import 'package:restaurant_app/widgets/platform_widget.dart';

class ListPage extends StatelessWidget {
  const ListPage({Key? key}) : super(key: key);

  Widget _list(BuildContext context) {
    return FutureBuilder<String>(
      future:
          DefaultAssetBundle.of(context).loadString('assets/restaurant.json'),
      builder: (context, snapshot) {
        final List<Restaurant> restaurant = parse(snapshot.data);
        return ListView.builder(
          itemCount: restaurant.length,
          itemBuilder: (context, index) {
            return _card(context, restaurant[index]);
          },
        );
      },
    );
  }

  Widget _card(BuildContext context, Restaurant restaurant) {
    return Material(
      child: ListTile(
        tileColor: listColor,
        selectedTileColor: baseColor,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6.0),
        leading: Hero(
          tag: restaurant.pictureId,
          child: Image.network(
            restaurant.pictureId,
            width: 100,
          ),
        ),
        title: Text(
          restaurant.name,
        ),
        subtitle: Text(
          'Rating ${restaurant.rating}',
          style: const TextStyle(color: ratingColor),
        ),
        onTap: () {
          Navigator.pushNamed(context, DetailPage.routeName,
              arguments: restaurant);
        },
      ),
    );
  }

  Widget _android(BuildContext context) {
    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        title: const Text(appName),
      ),
      body: _list(context),
    );
  }

  Widget _ios(BuildContext context) {
    return CupertinoPageScaffold(
      backgroundColor: baseColor,
      navigationBar: const CupertinoNavigationBar(
        middle: Text(appName),
        transitionBetweenRoutes: false,
      ),
      child: _list(context),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PlatformWidget(
      androidBuilder: _android,
      iosBuilder: _ios,
    );
  }
}
