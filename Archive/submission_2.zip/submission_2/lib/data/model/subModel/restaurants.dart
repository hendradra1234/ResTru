part of '../model.dart';

class Restaurant {
  late String id;
  late String name;
  late String description;
  late String pictureId;
  late String city;
  late String? address;
  late List<Categories>? categories;
  late num rating;
  late Menu? menus;
  late List<Review>? customerReviews;

  Restaurant({
    required this.id,
    required this.name,
    required this.description,
    required this.pictureId,
    required this.city,
    required this.rating,
    this.address,
    this.categories,
    this.menus,
    this.customerReviews,
    });

  factory Restaurant.fromJson(Map<String, dynamic> json) => Restaurant(
      id: json["id"],
      name: json["name"],
      description: json["description"],
      pictureId: json["pictureId"],
      address: json["address"],
      city: json["city"],
      rating: json["rating"].toDouble(),
      categories: json["categories"] == null
          ? null
          : List<Categories>.from(json['categories'].map((x) => Categories.fromJson(x))),
      menus: json['menus'] != null
        ? Menu.fromJson(json["menus"])
        : null,
      customerReviews: json["customerReviews"] == null
          ? null
          : List<Review>.from((json["customerReviews"] as List)
              .map((x) => Review.fromJson(x))
              .where((review) => review.name!.isNotEmpty)));

  String getSmallPicture() => Config.imgSmallURL + pictureId;

  String getMediumPicture() => Config.imgMediumURL + pictureId;

  String getLargePicture() => Config.imgLargeURL + pictureId;
}

