part of '../model.dart';

enum MenuType { food, drink }

class Menu {
  List<Option> foods;
  List<Option> drinks;

  Menu({
    required this.foods,
    required this.drinks,
  });

  factory Menu.fromJson(Map<String, dynamic> json) => Menu(
        foods: List<Option>.from(json["foods"].map((x) => Option.fromJson(x))),
        drinks: List<Option>.from(json["drinks"].map((x) => Option.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "foods": List<dynamic>.from(foods.map((i) => i.toJson())),
        "drinks": List<dynamic>.from(drinks.map((i) => i.toJson())),
      };
}
