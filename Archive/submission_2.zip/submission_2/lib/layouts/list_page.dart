import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:restaurant_app/common/styles.dart';
import 'package:restaurant_app/data/api/api_service.dart';
import 'package:restaurant_app/data/model/model.dart';
import 'package:restaurant_app/layouts/detail_page.dart';
import 'package:restaurant_app/provider/app_provider.dart';
import 'package:restaurant_app/widgets/custom_sliver_appbar.dart';
import 'package:restaurant_app/widgets/platform_widget.dart';
import 'package:lottie/lottie.dart';

class ListPage extends StatelessWidget {
  const ListPage({Key? key}) : super(key: key);

  Widget _lists(BuildContext context) {
    return Scaffold(
        backgroundColor: baseColor,
        body: ChangeNotifierProvider(
          create: (_) => AppProvider(apiService: ApiService()).getRestaurants(),
          child: CustomScrollView(
            slivers: [
              Consumer<AppProvider>(
                builder: (context, provider, _) {
                  return SliverPersistentHeader(
                    delegate: CustomSliverAppBar(
                        expandedHeight: 150, provider: provider),
                  );
                },
              ),
              const SliverToBoxAdapter(
                child: SizedBox(
                  height: 30,
                ),
              ),
              Consumer<AppProvider>(
                builder: (context, state, _) {
                  if (state.state == ResultState.loading) {
                    return const SliverFillRemaining(
                      child: Center(child: CircularProgressIndicator()),
                    );
                  } else if (state.state == ResultState.hasData) {
                    return SliverList(
                        delegate: SliverChildListDelegate(state
                            .result.restaurants
                            .map((restaurant) => _card(context, restaurant))
                            .toList()));
                  } else if (state.state == ResultState.error) {
                    return SliverFillRemaining(
                      child: Center(
                        child: Lottie.asset('assets/json/no_internet.json'),
                      ),
                    );
                  }
                  return SliverFillRemaining(
                    child: Center(
                        child: Lottie.asset('assets/json/search_empty.json')),
                  );
                },
              )
            ],
          ),
        ));
  }

  Widget _card(BuildContext context, Restaurant restaurant) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return DetailPage(restaurant: restaurant);
        }));
      },
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(15),
            child: Row(
              children: [
                Hero(
                    tag: restaurant.id,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CachedNetworkImage(
                        imageUrl: restaurant.getSmallPicture(),
                        width: 150,
                        height: 140,
                        fit: BoxFit.cover,
                        progressIndicatorBuilder: (context, data, _) =>
                            const Center(
                          widthFactor: 0.5,
                          child: CircularProgressIndicator(),
                        ),
                      ),
                    )),
                Flexible(
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          restaurant.name,
                          style: Theme.of(context).textTheme.headline6,
                          overflow: TextOverflow.visible,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          restaurant.description,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on,
                              size: 20,
                              color: locationColor,
                            ),
                            Text(restaurant.city),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            const Icon(
                              Icons.star,
                              size: 25,
                              color: ratingColor,
                            ),
                            Text("${restaurant.rating}"),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            color: dividerColor,
            height: 1,
            indent: 5,
            endIndent: 5,
          )
        ],
      ),
    );
  }

  Widget _android(BuildContext context) {
    return Scaffold(
      backgroundColor: baseColor,
      body: _lists(context),
    );
  }

  Widget _ios(BuildContext context) {
    return CupertinoPageScaffold(
      backgroundColor: baseColor,
      child: _lists(context),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PlatformWidget(
      androidBuilder: _android,
      iosBuilder: _ios,
    );
  }
}
